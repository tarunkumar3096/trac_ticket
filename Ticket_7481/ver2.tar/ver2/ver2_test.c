#include <stdio.h>
#include <queue_ver2.h>
#include <stdlib.h>
#include <ctype.h>
#define MAX_LENGTH 15
#define MAX_QUEUE 10
#include <string.h>
int queue_used[MAX_QUEUE];

void clear_buf(void)
{
	while (getchar() != '\n')
		;
}

unsigned int counter(struct queue_info *queue)
{
	int front = queue->front;
	int count = 0;

	if ((queue->front == -1) && (queue->rear == -1))
		return -1;
	do {
		if (front == queue->queue_len)
			front = 0;
		count++;
	} while (front++ != (queue->rear));

	return count - 1;
}

int display(struct queue_info *queue)
{
	int front = queue->front;

	if ((queue->front == -1) && (queue->rear == -1))
		return -1;

	do {
		if (front == queue->queue_len)
			front = 0;
		printf("%c ", queue->array[front]);
	} while (front++ != (queue->rear));

	printf("\n");
	return 0;
}

int put_data(struct queue_info *queue)
{
	char data;

	printf("enter the data to put in queue\n");
	scanf(" %c", &data);
	clear_buf();
	if (queue_put(queue, data))
		return -1;

	return 0;
}

int get_data(struct queue_info *queue)
{
	char data;

	if (queue_get(queue, &data))
		return -1;

	return data;
}

int put_bulk(struct queue_info *queue)
{
	int i = 0;
	char *arr;
	int buf_length = -1;
	int count = 0;

	while (1) {
		printf("Enter the length of the bulk data to put within %d\n",
		       ((queue->queue_len - 1) - counter(queue)));
		scanf("%d", &buf_length);
		clear_buf();
		if (!(isdigit(buf_length + '0')))
			printf("Invalid data\n");
		else
			break;
	}
	arr = malloc(sizeof(char) * (buf_length + 2));
	while (1) {
		printf("Enter the data of length %d\n", buf_length);
		fgets(arr, buf_length + 2, stdin);
		while ((arr[i] != '\n') && (i <= buf_length))
			i++;
		arr[i] = '\0';
		printf("i = %d\n", i - 1);
		if ((arr[buf_length] != '\n') && (arr[buf_length] != '\0')) {
			printf("in\n");
			clear_buf();
		}
		count = queue_put_bulk(queue, arr, strlen(arr));
		break;
	}
	free(arr);

	return count;
}

int get_bulk(struct queue_info *queue)
{
	char *arr;
	int buf_length;
	int count = 0;

	printf("Enter the length of the bulk data to get within %d\n",
	       counter(queue) + 1);
	scanf("%d", &buf_length);
	clear_buf();
	arr = malloc(sizeof(char) * buf_length);
	count = queue_get_bulk(queue, arr, buf_length);
	if (count != -1)
		printf("Bulk data from queue = %s\n", arr);
	free(arr);

	return count;
}

int queue_operation(struct queue_info *queue, int queue_number)
{
	int opr;
	char data;

	printf("\nData in queue[%d] buffer:\t", queue_number + 1);
	if (display(queue))
		printf("No data in buffer\n");
	printf("1.put\t2.get\t3.put_bulk\t4.get_bulk\t5.exit\n");
	scanf("%d", &opr);
	clear_buf();
	switch (opr) {
	case 1:
		if (put_data(queue))
			printf("Queue is full\n");
		break;
	case 2:
		data = get_data(queue);
		if (data == -1)
			printf("Queue is empty\n");
		break;
	case 3:
		data = put_bulk(queue);
		if (data == -1)
			printf("Queue is full\n");
		break;
	case 4:
		data = get_bulk(queue);
		if (data == -1)
			printf("Queue is empty\n");
		break;
	case 5:
		return 0;
	default:
		printf("Invalid options\n");
	}

	return 1;
}
void queue_buffer(struct queue_info *queue, int queue_number,
		  char *queue_buf, int count)
{
	int queue_length;

	while (1) {
		printf("Enter the details for queue[%d]:\n",
		       queue_number + 1);
		while (queue_used[queue_number] != 1) {
			printf("Enter the Queue length within");
			printf("%d for queue[%d]\n",
			       MAX_LENGTH, queue_number + 1);
			scanf("%d", &queue_length);
			queue_buf = malloc(sizeof(char) * queue_length);
			clear_buf();
			if ((queue_length > MAX_LENGTH) || (queue_length < 1)) {
				printf("invalid data\n");
				continue;
			}
			queue_used[queue_number] = 1;
			queue_init(queue, queue_buf, queue_length);
		}
		while (1) {
			if (queue_operation(queue, queue_number))
				;
			else
				return;
		}
	}
}

int queue_form(int count)
{
	struct queue_info queue[count];
	char *queue_buf[count];
	int queue_number;
	char queue_switcher;

	while (1) {
		printf("Enter the queue number to switch between %d\n", count);
		scanf("%d", &queue_number);
		clear_buf();
		queue_number -= 1;
		if ((queue_number > count) || (queue_number < 0)) {
			printf("invalid data\n");
			continue;
		}
		queue_buffer(&queue[queue_number], queue_number,
			     queue_buf[queue_number - 1], count);
		printf("want to switch queue(y/n)\n");
		scanf(" %c", &queue_switcher);
		clear_buf();
		if ((queue_switcher == 'y') || (queue_switcher == 'Y'))
			continue;
		else
			break;
	}

	free(queue_buf);
	return 0;
}

int main(void)
{
	int count;

	while (1) {
		printf("Enter the number of queue within %d\n", MAX_QUEUE);
		scanf("%d", &count);
		clear_buf();
		if ((count > MAX_QUEUE) || (count < 1)) {
			printf("Invalid data\n");
			continue;
		}
		break;
	}
	queue_form(count);
	return 0;

}
