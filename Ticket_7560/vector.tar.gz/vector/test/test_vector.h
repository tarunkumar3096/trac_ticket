/*
 * get_int() - This function will get the integer data from user.
 * 
 * This function will validate the integer given by user.
 * Return: 0 for success and -1 for failure
 */
static int get_int(void);
/*
 * display() - display the data available in vector.
 * @arg1: It is pointer to the struct vector_node.
 *
 * It will display the data based on the datatype in vector.
 * Return: 0 for success and -1 for failure
*/
static int display(struct vector_node *element);
/*
 * inserting() - This function for inserting data in the vector.
 * @arg1: It is pointer to the struct vector. 
 * @arg2: It is pointer to the struct vector_node.
 *
 * It will do append, prepend, insert at particular position and set the data in position.
 * Return: 0 for success and -1 for failure 
*/
static int inserting(struct vector *vector, struct vector_node *data);

/*
 * deleting() - This funtion will remove the node from vector.
 * @arg1: It is pointer to the struct vector.
 * 
 * It will do chop, behead, delete at paricular position in the  vector.
 * Return: 0 for success and -1 for failure
 */ 
static int deleting(struct vector *vector);
/*
 * getting_data - This function will get the data from vector.
 * @arg1: It is pointer to the struct vector.
 * 
 * This function will get the data from first, last and particular position from vector.
 * Return: 0 for success and -1 for failure
 */
static int getting_data(struct vector *vector);
/*
 * vector_availability - This function will check the available of the data in vector.
 * @arg1: It is pointer to the struct vector.
 * 
 * is_empty, size are the two function used by this function to find the data in vector.
 * Return: 0 for success and -1 for failure
 */
static int vector_availability(struct vector *vector);

/*
 * flush() -  This function will clear data in the vector.
 * @arg1: It is pointer to the struct vector.
 * 
 * This function will call clear, destruct api to free vector.
 * Return: 0 for success and -1 for failure
 */
static int flush(struct vector *vector);
/*
 * spliter() - This function will split the vecto into.
 * @arg1: It is pointer to the struct vector.
 *
 * It will get the position from user and split the vector into two.
 * Return: 0 for success and -1 for failure
 */
static int spliter(struct vector *vector);

/*
 * move_data() - This function get the  argument to move data in vector.
 * @arg1: It is pointer to the struct vector.
 *
 * It will old_position and new_position to move the data in vector.
 * Return: 0 for success and -1 for failure
 */
static int move_data(struct vector *vector);
