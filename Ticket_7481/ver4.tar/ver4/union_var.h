union g_datatype
{
	char char_d;
	short short_d ;
	int int_d;
	long long_d;
	float float_d;
	double double_d;
};

struct queue_info
{
	int front;
	int rear;
	int queue_len;
	int type;
	union g_datatype *array;	
};

enum g_typename {
	char_g = 1,
	short_g,
	int_g,
	long_g,
	float_g,
	double_g,
};

void queue_init_generic(struct queue_info *queue, union g_datatype *generic, enum g_typename, int queue_len);
int queue_put_generic(struct queue_info *queue, union g_datatype *generic);
int queue_get_generic(struct queue_info *queue, union g_datatype *generic);
