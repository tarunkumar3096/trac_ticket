#include <stdio.h>
#include <queue_ver2.h>

void queue_init(struct queue_info *queue, char *queue_buf, int queue_len)
{
	queue->queue_len = queue_len;
	queue->array = queue_buf;
	queue->front = -1;
	queue->rear = -1;
}


int queue_put(struct queue_info *queue, char value)
{
	if (queue->front == (queue->rear + 1) % queue->queue_len)
		return -1;

	if (queue->front == -1)
		queue->front = 0;
	queue->rear = (queue->rear + 1) % queue->queue_len;
	queue->array[queue->rear] = value;

	return 0;
}

int queue_get(struct queue_info *queue, char *value)
{
	if ((queue->front == -1) && (queue->rear == -1))
		return -1;

	*value = queue->array[queue->front];

	if (queue->front == queue->rear) {
		queue->front = -1;
		queue->rear = -1;
	} else {
		queue->front = (queue->front + 1) % (queue->queue_len);
	}

	return 0;
}

int queue_put_bulk(struct queue_info *queue, char *values, int len)
{
	int temp = 0;

	while (temp != len) {
		if (queue_put(queue, values[temp]))
			break;
		temp++;
	}
	if (temp)
		return 0;

	return -1;
}

int queue_get_bulk(struct queue_info *queue, char *values, int len)
{
	int temp = 0;
	char get;

	while (temp != len) {
		if (!queue_get(queue, &get))
			values[temp] = get;
		else
			return -1;
		temp++;
	}

	return 0;
}
