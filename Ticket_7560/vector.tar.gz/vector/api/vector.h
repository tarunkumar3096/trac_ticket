#ifndef __VECTOR_H__
#define __VECTOR_H__

typedef union g_datatype {
	char char_g;
	short short_g;
	int int_g;
	long long_g;
	float float_g;
	double double_g;
} g_datatype;

enum g_typename {
	CHAR,
	SHORT,
	INT,
	LONG,
	FLOAT,
	DOUBLE
};

struct element {
	g_datatype field;
	enum g_typename field_type;
};

struct vector_node {
	struct element element;
	struct vector_node *next;
	struct vector_node *prev;
};

struct vector {
	struct vector_node *head;
	struct vector_node *tail;

	int (*append)(struct vector *vector, struct element element);
	int (*prepend)(struct vector *vector, struct element element);
	int (*insert)(struct vector *vector, int pos, struct element element);
	int (*chop)(struct vector *vector);
	int (*behead)(struct vector *vector);
	int (*delete)(struct vector *vector, int pos);
	int (*set)(struct vector *vector, int pos, struct element element);
	int (*get)(struct vector *vector, int pos, struct element *element);
	int (*is_empty)(struct vector *vector);
	int (*first)(struct vector *vector, struct element *element);
	int (*last)(struct vector *vector, struct element *element);
	int (*clear)(struct vector *vector);
	int (*destruct)(struct vector *vector);
	int (*size)(struct vector *vector);
	int (*move)(struct vector *vector, int old_pos, int new_pos);
	struct vector * (*splice)(struct vector *vector, int pos);
};

#define ELEMENT(data, type) (						\
			     (struct element) { .field = (g_datatype)data, \
					     .field_type = type})

#define for_each(entry, vector)				\
	for (struct vector_node *entry = vector->head;	\
	    entry != NULL; entry = entry->next)

#define for_each_rev(entry, vector)			\
	for (struct vector_node *entry = vector->tail;	\
	    entry != NULL; entry = entry->prev)

#define VALUE(entry)  entry->element.field
#define VALUE_F(entry) entry->element.field.float_g
#define VALUE_D(entry) entry->element.field.double_g
#define TYPE(entry)   entry->element.field_type

/* # Public APIs # */
/*
 * vector() - This function initialization of struct vector members
 * @arg1: It is pointer to struct vector
 *
 * This function will assign values to head, tail.
 * Assign address of function to function pointer
 *
 * Return: It return scalar type of struct vector
 */
struct vector vector(struct vector *vector);

#ifdef __static_fun__
/* # Internal APIs # */
/*
 * append() - This function for appending element to end of the vector.
 * @arg1: It is pointer to struct vector.
 * @arg2: It is structure element.
 *
 * This function for appending element to end of the vector.
 * Returns: 0 for success and -1 for not possible to add at end,
 * when no data present in vector and -1 for unable to allocate memory.
 */
static int append(struct vector *vector, struct element element);

/*
 * prepend() - This function will add element to vector.
 * @arg1: It is pointer to struct vector.
 * @arg2: It is structure element.
 *
 * This function for adding element to beginning of the vector.
 * Retuns: 0 for success and -1 for not possible to add at beginning,
 * when no data present in vector and -1 for unable to allocate memory.
 */
static int prepend(struct vector *vector, struct element element);

/*
 * insert() - This function will insert add element to vector.
 * @arg1: It is pointer to struct vector.
 * @arg2: It is a integer pointer.
 * @arg3: It is structure element.
 *
 * This function for inserting data at particular position given by argument.
 * Returns: 0 for success and -1 for not possible to insert at given position.
 *  -1 for unable to allocate memory.
 */
static int insert(struct vector *vector, int pos, struct element element);

/*
 * chop() - This function will delete data at end.
 * @arg1: It is pointer to struct vector.
 *
 * If data available in vector, it will delete data at end.
 * Returns: 0 for success and -1 for not possible to remove data in vector,
 *  when no data available in vector.
 */
static int chop(struct vector *vector);

/*
 * behead() - This function for removing the data at beginning of the vector.
 * @arg1: It is pointer to struct vector.
 *
 * If data available in vector, it will delete data head of the vector.
 * Returns: 0 for success and -1 for not possible to remove data in vector,
 * when no data available in vector.
 */
static int behead(struct vector *vector);

/*
 * delete() - This function will remove data from vector.
 * @arg1: It is pointer to struct vector.
 * @arg2: It is an integer datatype
 *
 * This function for removing the data at the particular position of the vector.
 * And free the allocated memory.
 * Returns: 0 for success and -1 for not possible to remove at given position.
 */
static int delete(struct vector *vector, int pos);

/* Removes all the elements, but vector is available for other operations */
/*
 * clear() - This function will clear data in vector.
 * @arg1: It is pointer to struct vector.
 *
 * This function will clear data in vector by free it.
 * Return: 0 for success and -1 when no data available in vector.
 */
static int clear(struct vector *vector);

/* Frees the complete vector useful only when dynamically allocated */
/*
 * destruct() - This function will free the vector memory completely.
 * @arg1: It is pointer to struct vector.
 *
 * This funtion will clear all data including vector by freeing it.
 * NOTE: should not use the vector after freeing it.
 *
 * Return: 0 for success and -1 for NULL pointer passed to the argument.
 */
static int destruct(struct vector *vector);

/*
 * move() - This function will move the data in vector.
 * @arg1: It is pointer to struct vector.
 * @arg2: It is a integer pointer.
 * @arg3: It is structure element.
 *
 * It will move the data from old_pos to new_pos as passed in argument.
 * Return: 0 for success and -1 for unable to move data in vector.
 */
static int move(struct vector *vector, int old_pos, int new_pos);

/*
 * set() - This function will set the data in the vector.
 * @arg1: It is pointer to struct vector.
 * @arg2: It is a integer pointer.
 * @arg3: It is structure element.
 *
 * It will set the data in the particular position passed by the argument.
 * Returns: 0 for success and -1 for not possible to change in that position.
 */
static int set(struct vector *vector, int pos, struct element element);

/* Gives the element value but doesn't alter the list */
/*
 * first() - This function will get data from vector head.
 * @arg1: It is pointer to struct vector.
 * @arg2: It is pointer to structure element.
 *
 * It will get data from vector head location.
 * Return: 0 for success and -1 when no data available in vector.
 */
static int first(struct vector *vector, struct element *element);

/*
 * last() - This function will get data from vector tail.
 * @arg1: It is pointer to struct vector.
 * @arg2: It is pointer to structure element.
 *
 * It will get data from vector tail location.
 * Return: 0 for success and -1 when no data available in vector.
 */
static int last(struct vector *vector, struct element *element);
/*
 * get() - This function will get data from vector at position.
 * @arg1: It is pointer to struct vector.
 * @arg2: It is integer datatype.
 * @arg2: It is pointer to structure element.
 *
 * It will get data from vector at the particular location passed by argument.
 * Return: 0 for success and -1 when no data available in vector.
 */
static int get(struct vector *vector, int pos, struct element *element);

/*
 * is_empty - This function will check data is available in vector or not.
 * @arg1: It is pointer to struct vector.
 *
 * This function will check whether data is available in vector or not.
 * Return: 0 for data available in vector.
 *         -1 for no data in vector.
 */
static int is_empty(struct vector *vector);
/*
 * size() - This function will count number of element in vector.
 * @arg1: It is pointer to struct vector.
 *
 * This function will return number of element present in the vector.
 * Return: -1 for failure and integer value for size of vector.
 */
static int size(struct vector *vector);

/* Splices the vector into two and returns second vector which starts from `pos`
 *
 * splice() - This function split the vector into two based on the pos.
 * @arg1: It is pointer to struct vector.
 * @arg2: It is integer datatype.
 *
 * This function will split the vector into two.
 * return second vector head address.
 * Returns: NULL if position is not found or structure address of position
 * based on the pos.
 */
static struct vector *splice(struct vector *vector, int pos);

#endif
#endif /* __VECTOR_H__ */
