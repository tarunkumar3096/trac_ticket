#include <stdio.h>
#include <queue_ver1.h>
#define MAX_LENGTH 15

void clear_buf(void)
{
	while (getchar() != '\n')
		;
}
int display(struct queue_info *queue)
{
	int i = queue->front;

	if ((queue->front == -1) && (queue->rear == -1))
		return -1;

	 do {
		if (i == queue->queue_len)
			i = 0;
		printf("%c ", queue->array[i]);
	 } while (i++ != (queue->rear));

	printf("\n");

	return 0;
}

int put_data(struct queue_info *queue)
{
	char data;

	printf("enter the data to put in queue\n");
	scanf(" %c", &data);
	if (queue_put(queue, data))
		return -1;

	return 0;
}

int get_data(struct queue_info *queue)
{
	char data;

	if (queue_get(queue, &data))
		return -1;

	return data;
}

int main(void)
{
	struct queue_info queue;
	char queue_buf[MAX_LENGTH];
	char data;
	int queue_length;
	int opr;
	char loop_breaker;
	int opr_break = 1;

	while (1) {
		printf("Enter the details for queue:\n");
		printf("Enter the Queue length within %d\n", MAX_LENGTH);
		scanf("%d", &queue_length);
		clear_buf();
		if ((queue_length > MAX_LENGTH) || (queue_length < 1)) {
			printf("invalid data\n");
			continue;
		}
		queue_init(&queue, queue_buf, queue_length);
		while (opr_break) {
			printf("\nData in buffer:\t");
			if (display(&queue))
				printf("No data in buffer\n");
			printf("1.put\t2.get\t3.exit\n");
			scanf("%d", &opr);
			clear_buf();
			switch (opr) {
			case 1:
				if (put_data(&queue))
					printf("Queue is full\n");
				break;
			case 2:
				data = get_data(&queue);
				if (data == -1)
					printf("Queue is empty\n");
				break;
			case 3:
				opr_break = 0;
				break;
			default:
				printf("Invalid options\n");
			}			
		}
		printf("Calculate again(y/n)\n");
		scanf(" %c", &loop_breaker);
		clear_buf();
		if ((loop_breaker == 'y') || (loop_breaker == 'Y'))
			continue;
		else
			break;
	}
	return 0;
}
