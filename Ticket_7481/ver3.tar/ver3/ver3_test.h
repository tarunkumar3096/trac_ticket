#define FLOW_CONTROLLED 1
#define DISCARD_ON_OVERFLOW 2
#define PARTIAL_RW 3

struct queue_info
{
	int front;
	int rear;
	int queue_len;
	int config;
	char *array;
};

void queue_init(struct queue_info *queue, char *queue_buf, int queue_len);
int queue_put(struct queue_info *queue, char value);
int queue_get(struct queue_info *queue, char *value);
int queue_put_bulk(struct queue_info *queue, char *values, int len);
int queue_get_bulk(struct queue_info *queue, char *values, int len);
void queue_reset(struct queue_info *queue);
int queue_flush(struct queue_info *queue, char *values, int *len);
int queue_config(struct queue_info *queue, int config); /* flag can be FLOW_CONTROLLED, DISCARD_ON_OVERFLOW, PARTIAL_RW */
