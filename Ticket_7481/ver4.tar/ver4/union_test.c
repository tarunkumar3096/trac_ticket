#include <stdio.h>
#include <union_var.h>
#include <strings.h>
#include <stdlib.h>
#define MAX_QUEUE 10
#define MAX_LENGTH 15
int queue_used[MAX_LENGTH];

void clear_buf(void)
{
	while (getchar() != '\n')
		;
}

int display(struct queue_info *queue)
{
	int i = queue->front;

	if ((queue->rear == -1) && (queue->front == -1))
		return -1;

	do {
		if (i == queue->queue_len)
			i = 0;
		switch (queue->type) {
		case char_g:
			printf("%c\t", queue->array[i].char_d);
			break;
		case short_g:
			printf("%d\t", queue->array[i].short_d);
			break;
		case int_g:
			printf("%d\t", queue->array[i].int_d);
			break;
		case long_g:
			printf("%ld\t", queue->array[i].long_d);
			break;
		case float_g:
			printf("%f\t", queue->array[i].float_d);
			break;
		case double_g:
			printf("%.10lf\t", queue->array[i].double_d);
			break;
		}
	} while (i++ != (queue->rear));
	printf("\n");
	return 0;
}

void put_data(struct queue_info *queue, union g_datatype *data_sender)
{
	printf("enter the data to put in queue\n");

	switch (queue->type) {
	case char_g:
		scanf(" %c", &data_sender->char_d);
		break;
	case short_g:
		scanf("%hd", &data_sender->short_d);
		break;
	case int_g:
		scanf("%d", &data_sender->int_d);
		break;
	case long_g:
		scanf("%ld", &data_sender->long_d);
		break;
	case float_g:
		scanf("%f", &data_sender->float_d);
		break;
	case double_g:
		scanf("%lf", &data_sender->double_d);
		break;
	}
	if (queue_put_generic(queue, data_sender))
		printf("Queue is full\n");
	clear_buf();
}

void get_data(struct queue_info *queue, union g_datatype *data_receiver)
{
	if (queue_get_generic(queue, data_receiver)) {
		printf("Queue is empty");
	} else {
		switch (queue->type) {
		case char_g:
			printf("get char = %c\n", data_receiver->char_d);
			break;
		case short_g:
			printf("get short = %d\n", data_receiver->short_d);
			break;
		case int_g:
			printf("get int = %d\n", data_receiver->int_d);
			break;
		case long_g:
			printf("get long = %ld\n", data_receiver->long_d);
			break;
		case float_g:
			printf("get float = %f\n", data_receiver->float_d);
			break;
		case double_g:
			printf("get double = %lf\n", data_receiver->double_d);
			break;
		}
	}
}

int queue_operation(struct queue_info *queue, int queue_number)
{
	int opr;
	union g_datatype data_sender;
	union g_datatype data_receiver;

	while (1) {
		printf("\nData in buffer:\t");
		if (display(queue))
			printf("No data in buffer\n");
		printf("1.put\t2.get\t3.exit\n");
		scanf("%d", &opr);
		clear_buf();
		switch (opr) {
		case 1:
			put_data(queue, &data_sender);
			break;
		case 2:
			get_data(queue, &data_receiver);
			break;
		case 3:
			return 0;
		case 4:
			printf("Invalid options\n");
		}
		return 1;
	}
}

void queue_buffer(struct queue_info *queue, int queue_number,
		  union g_datatype *queue_buf, int count)
{
	int queue_length;
	int data_type;
	enum g_typename type;

	while (1) {
		printf("Enter the details for queue[%d]:\n",
		       queue_number + 1);
		while (queue_used[queue_number] != 1) {
			printf("Enter the Queue length within ");
			printf("%d for queue[%d]\n",
			       MAX_LENGTH, queue_number + 1);
			scanf("%d", &queue_length);
			if ((queue_length > MAX_QUEUE) || (queue_length < 1)) {
				printf("invalid data\n");
				continue;
			}
			queue_buf = malloc(sizeof(union g_datatype) *
					   queue_length);
			clear_buf();
			if ((queue_length > MAX_LENGTH) || (queue_length < 1)) {
				printf("invalid data\n");
				continue;
			}
			printf("Enter the type of datatype");
			printf("\n1.char\n2.short\n");
			printf("3.int\n4.long\n5.float\n6.double\n");
			scanf("%d", &data_type);
			type = data_type;
			clear_buf();
			if ((type < 1) || (type > 6)) {
				printf("invaild data\n");
				continue;
			}
			queue_used[queue_number] = 1;
			queue_init_generic(queue, queue_buf, type, queue_length);
		}
		while (1) {
			if (queue_operation(queue, queue_number))
				;
			else
				return;
		}
	}
}

int queue_form(int count)
{
	struct queue_info queue[count];
	union g_datatype *queue_buf[count];
	int queue_number;
	char queue_switcher;
	int i = 0;

	while (1) {
		printf("Enter the queue number to switch between %d\n", count);
		scanf("%d", &queue_number);
		clear_buf();
		queue_number -= 1;
		if ((queue_number >= count) || (queue_number < 0)) {
			printf("invalid data\n");
			continue;
		}
		queue_buffer(&queue[queue_number], queue_number,
			     queue_buf[queue_number - 1], count);
		printf("want to switch queue(y/n)\n");
		scanf(" %c", &queue_switcher);
		clear_buf();
		if ((queue_switcher == 'y') || (queue_switcher == 'Y'))
			continue;
		else
			break;
	}

	while (i++ != count) {
		if (queue_used[i])
			free(queue_buf[i]);
	}

	return 0;
}

int main(void)
{
	int count;

	while (1) {
		printf("Enter the number of queue within %d\n", MAX_QUEUE);
		scanf("%d", &count);
		clear_buf();
		if ((count >= MAX_QUEUE) || (count < 1)) {
			printf("Invalid data\n");
			continue;
		}
		break;
	}
	queue_form(count);
	return 0;

}
