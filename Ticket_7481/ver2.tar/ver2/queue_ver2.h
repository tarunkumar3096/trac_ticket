struct queue_info
{
	int front;
	int rear;
	int queue_len;
	char *array;
};
void queue_init(struct queue_info *queue, char *queue_buf, int queue_len);
int queue_put(struct queue_info *queue, char value);
int queue_get(struct queue_info *queue, char *value);
int queue_put_bulk(struct queue_info *queue, char *values, int len);
int queue_get_bulk(struct queue_info *queue, char *values, int len);
	
	
